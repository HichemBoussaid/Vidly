
const Joi = require('@hapi/joi');
const express = require("express");
const { string } = require('@hapi/joi');
const { cpuUsage } = require('process');
const app = express();
app.use(express.json());
var films = [
    {id : 1, name : 'The Road Warrior (1982) (aka Mad Max 2 (1981, Australia))', genre : 'Action' },
    {id : 2, name : 'Aliens (1986)', genre : 'Action' } ,
    {id : 3, name : 'Die Hard (1988)', genre : 'Action' },
    {id : 4, name : 'Terminator 2: Judgment Day (1991)', genre : 'Action' },
    {id : 5, name : 'Casino Royale (2006)', genre : 'Action' },
    {id : 6, name :'E.T. - The Extra-Terrestrial (1982)', genre : 'Fantasy'},
    {id : 7, name : 'The Princess Bride (1987)', genre : 'Fantasy'},
    {id : 8, name : 'Harry Potter Franchise (2001-2011)', genre : 'Fantasy'},
    {id : 9, name : 'The Lord of the Rings Trilogy (2001-2003)', genre : 'Fantasy'},
    {id : 10, name : 'Pan\'s Labyrinth (2006)', genre : 'Fantasy' },
    {id : 11, name :'Snow White and the Seven Dwarfs (1937)', genre : 'Animated'},
    {id : 12, name : 'Fantasia (1940)', genre : 'Animated'},
    {id : 13, name : 'Beauty and the Beast (1991)', genre : 'Animated'},
    {id : 14, name : 'Toy Story (1995)', genre : 'Animated'},
    {id : 15, name : 'Spirited Away (2001)', genre : 'Animated'}
]


app.get('/',(req,res)=>{
    res.send("Hello World");
} );

app.get('/api/films',(req,res)=>{
    res.send(films)
});

app.get('/api/films/:genre',(req,res)=>{
    const film = films.filter(f => (f.genre) === (req.params.genre));
    
    if(!film) return res.status(404).send("This genre does not exist");

    res.send(film)
});
app.get('/api/genres',(req,res)=>{
    var genres = [];

    var map1 = films.map(f => ((genres.indexOf(f.genre)===-1) ?   genres.push(f.genre) : console.log(f.genre+" "+f.id) ) ) ;
    res.write(JSON.stringify(genres));
    res.end();
})

app.put('/api/films/:id',(req,res)=>{
    const film = films.find(f => f.id === parseInt(req.params.id));

    if(!film) return res.status(404).send("This film isn't on the list");
    else {
        result = schemaValidation(req.body);
        if(result.error) return res.status(400).send(result.error.details[0].message);
        else{
            film.name=req.body.name;
            film.genre=req.body.genre;
            res.send(film);
        }
    }
})
app.delete('/api/films/:id',(req,res)=>{
    const film = films.find(f => f.id === parseInt(req.params.id));
    if(!film) return res.status(404).send("This film isn't on the list");
    else {
        const index = films.indexOf(film);
        films.splice(index,1);
        res.send(films);
    }
});


app.post('/api/films',(req,res) =>{
    result= schemaValidation(req.body);
    console.log(result)
    if(result.error ){
        return res.status(400).send(result.error.details[0].message);
    } 
    else{
        var  newFilm = films.find(f => f.name === req.body.name)
        if(!newFilm){
            const film = {
                id : films.length+1 ,
                name : req.body.name,
                genre : req.body.genre
            }
            films.push(film);
            res.send(films);
        }

        else return res.status(400).send("This film already exists");
    }

});

function schemaValidation(arg ){
    const schema = Joi.object({
        name : Joi.string().min(3).required(),
        genre : Joi.string().min(3).required()
    })
    const result = schema.validate(arg);
    return result;
}
app.listen('3000');